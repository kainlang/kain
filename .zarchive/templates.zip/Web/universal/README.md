# Universal Web Template

`universal/` is the serious Kain web starter that assumes:

- users should not need `rustc` or `cargo`
- Kain is still the orchestration language
- Node FFI is the practical browser/runtime lane today
- Kain UI should still shape authoring and preview where it already has real semantic strength

## Entry Points

- `src/main.kn`
  - builds the full experience matrix into `outputs/sites`
- `src/build.kn`
  - bundles client islands and builds the full experience matrix
- `src/serve.kn`
  - serves the default experience over the Node runtime
- `src/native_preview.kn`
  - semantic Kain UI preview surface for the pack
- `src/actor_server.kn`
  - prints the actor report for the hybrid actor-oriented experience

## Runtime Surface

- `helpers/web_runtime.mjs`
  - manifest loader
  - HTML and client-island renderer
  - client bundler (Preact + Three.js) for React/TypeScript-esque islands
  - KainScript (`.ks`) support in the client bundle loader
  - PWA manifest, offline fallback, and service worker output
  - local search, frontend stack + Kain UI stack + UI runtime + UI state/routing/data/forms/motion/testing/tooling stacks, chat runtime, actor runtime, agent knowledge/memory/tool registries, chat (playbooks/tools/memory), prompt-deck, UI kit, catalog, app/auth/commerce data (product catalog, inventory, fulfillment, shipping, returns, loyalty, referrals, customer portal, ads), data platform, realtime, 3D scene assets/materials/lighting/cameras/animation/physics/audio/XR/shaders, growth/experiments/service catalog, creative systems (copy decks, content models, editorial flow, email templates, campaigns, icon/motion/illustration libraries), support + feedback + survey + messaging + payments + scheduling + privacy lanes, actor jobs/schedules/hosts, runtime hosts + deployment targets, session, uploads, analytics, form, and route APIs
  - static artifact writer
  - actor-aware local HTTP + SSE + WebSocket server with agent-scoped chat routing
- `package.json`
  - Node scripts for build, inspect, and local serving

### Runtime Routing + Storage Config

`manifests/app.json` now owns the runtime storage + endpoint layout so the Node FFI lane is fully data-driven:

```json
"site_runtime": {
  "host": "127.0.0.1",
  "default_port": 4318,
  "storage": {
    "root": "runtime",
    "submissions": "submissions",
    "uploads": "uploads",
    "analytics": "analytics",
    "auth": "auth",
    "chat": "chat"
  },
  "routes": {
    "chat": "/api/chat",
    "chat_stream": "/api/chat/stream",
    "chat_ws": "/ws/chat",
    "realtime_stream": "/api/realtime/stream",
    "realtime_ws": "/ws/realtime",
    "uploads": "/api/uploads",
    "uploads_prefix": "/uploads/",
    "analytics_event": "/api/analytics/event",
    "analytics_events": "/api/analytics/events"
  }
}
```

These values flow into `site.data.json`, `system.contract.json`, and the island hydration contract so client islands stay consistent without hard-coded endpoints.

## Manifest Surface

- `manifests/app.json`
  - top-level app, output, SEO, and runtime configuration
- `manifests/themes/*.json`
  - visual systems
- `manifests/content/*.json`
  - copy, pricing, testimonials, docs links, prompts, forms, routes, growth/experiment/service data, and search documents
- `manifests/scenes/*.json`
  - immersive scene descriptors
- `manifests/experiences/*.json`
  - final archetype compositions and section layouts

## Archetypes Included

- `business_launch`
- `portfolio_signal`
- `immersive_luminous`
- `chat_orbit`
- `actor_mesh_foundry`
- `knowledge_atlas`
- `operator_foundry`
- `hybrid_command`
- `app_foundry`
- `commerce_signal`
- `realtime_constellation`

## Artifacts Emitted Per Experience

- `index.html`
- `blog/index.html` (when `content.blog_posts` is configured)
- `blog/<slug>/index.html` (markdown-driven post pages)
- `site.manifest.json`
- `actor-server.plan.json`
- `site.data.json`
- `system.contract.json`
- `ui.schema.json`
- `sitemap.xml`
- `robots.txt`
- `feed.xml`
- `manifest.webmanifest`
- `service-worker.js`
- `offline/index.html`
- `icon.svg`
- `social-card.svg`

## Shared Artifacts (Written Once Per Build)

- `../client/kain-client.bundle.js`
- `../client/kain-client.bundle.js.meta.json`

## Typical Usage

Install dependencies:

```powershell
npm install
```

Use the Kain entrypoint:

```powershell
kain run src/main.kn
kain run src/build.kn
kain run src/serve.kn
```

Use the Node-only scripts:

```powershell
npm run build
npm run catalog
npm run serve:hybrid
npm run serve:docs
npm run serve:operator
npm run serve:app
npm run serve:commerce
npm run serve:realtime
npm run experience:hybrid
npm run actor:hybrid
npm run contract:hybrid
npm run ui:hybrid
```

Client bundle only:

```powershell
npm run bundle:client
```

KainScript support:

- `helpers/client/lib/kain_script_bridge.ks` is a sample KainScript module used by the client bundle.
- `.ks` files are bundled alongside TS/TSX without requiring Rust tooling.

Switch to a TypeScript-aware helper runtime by changing `[node_ffi]` in
`KAIN.toml` from `node` to `npx` with `tsx`.

New reusable section kinds in this pass:

- `prompt_deck`
- `process_steps`
- `capability_matrix`
- `blueprint_grid`
- `app_shell`
- `auth_panel`
- `auth_session`
- `commerce_stack`
- `integration_grid`
- `realtime_channels`
- `data_collections`
- `experience_catalog` (experience matrix island)
- `uploads_lab`
- `analytics_lab`
- `card_grid` with `content.chat_personas`
- `card_grid` with `content.chat_modes`
- `process_steps` with `content.chat_playbooks`
- `card_grid` with `content.chat_tools`
- `card_grid` with `content.chat_memory`
- `process_steps` with `content.actor_playbooks`
- `card_grid` with `content.actor_tools`
- `actor_topology`
- `actor_ops` (actor control island)
- `agent_studio` (agent routing + workflow island)
- `ui_kit` (UI components + layouts + tokens island)
- `ui_stacks` (UI runtime + state/routing/data/forms/motion/testing/tooling island)
- `system_contract` (system contract explorer island)
- `metric_grid` with `content.actor_metrics`
- `status_board`
- `roadmap_timeline`
- `team_grid`
- `partner_grid`
- `press_kit`
- `careers_list`
- `support_grid`
- `security_grid`
- `growth_stack`
- `experiment_board`
- `service_catalog`
- `success_playbooks`
- `notification_matrix`
- `release_notes`
- `feature_flags`
- `incident_response`
- `crm_pipeline`
- `community_hub`
- `event_schedule`
- `newsletter_panel`
- `compliance_grid`
- `observability_stack`
- `infrastructure_stack`
- `localization_grid`
- `accessibility_grid`
- `performance_targets`
- `legal_links`

New system registries in this pass:

- identity providers, roles, and access policies
- tenant management and workspace isolation registries
- SSO and SCIM provisioning stack registry
- API key management registry (service accounts, scopes, rotation)
- identity verification lanes
- fraud and risk controls
- consent and preference center metadata
- audit log metadata
- data export pipelines
- billing plans, invoices, and tax metadata
- subscription tiers and entitlements
- CMS content types and editorial workflow
- media libraries and asset pipelines
- automation flows and webhook event contracts
- API reference registry + developer portal tools
- SEO targets and social metadata
- PWA stack registry (install, service worker, app badge)
- offline support registry (fallback, cache, sync)
- personalization registry (segments, variants, context signals)
- chat agent roster, tools, and workflows
- UI components, layouts, and design token registries
- frontend stack registry (TypeScript/React-like runtime, routing, state, data, build)
- Kain UI stack registry (semantic contracts, reload, workspace semantics, shader canvas, preview loop)
- UI state, routing, data, form, motion, testing, and tooling stack registries for React/TypeScript-style shells
- UI runtime registry (schema, modules, islands, tokens, layouts)
- chat runtime registry (streaming, personas, playbooks, tools, memory, safety)
- actor runtime registry (routes, mesh, supervision, queues, metrics, tools)
- FFI bridge registry (Node, browser, and native adapters)
- KainScript module registry for client islands and utilities
- client runtime stack registry (islands, state, hydration)
- server runtime stack registry (actor server runtime, routing, persistence)
- frontend framework targets (React/Next/Remix/Astro/SvelteKit/Vue/Solid compatibility planning)
- expanded UI component + layout recipes (portfolio, docs, commerce, realtime)
- expanded infrastructure + observability stack metadata (edge, serverless, data, logs, cost)
- database, queue, secrets, config, and background job stack registries
- expanded security controls and performance/accessibility targets
- actor policies and actor metrics
- scene pipeline, render stack, interaction modes, and device profiles
- model stack, voice stack, moderation policies, AI evaluation suites, AI guardrails, and prompt library registries
- actor supervision and actor queue registries
- data governance and backup plan registries
- support tickets, feedback loops, and survey programs
- messaging, payments, scheduling, and privacy request registries
- enablement programs, onboarding flows, reliability SLOs, data retention policies, and incident history registries
- product catalog and inventory stack registries
- fulfillment, shipping, and returns policy registries
- loyalty and referral program registries
- paid acquisition and personalization stack registries
- customer portal registry
- data platform registry
- integration marketplace registry (partner tiers + install hooks)
- event bus registry (pub/sub + worker queues)
- data pipeline registry (ELT, feature store, lakehouse)
- analytics stack registry
- attribution stack registry
- data warehouse registry
- CDP registry
- release notes and changelog entries
- feature flag registry
- incident response playbooks
- operational runbooks registry
- CRM pipeline stages
- scene asset, material, lighting, camera, animation, physics, spatial audio, XR, and shader registries
- streaming stack registry for chat + ops previews
- knowledge sources, memory stores, tool registry, and agent workflow registries
- actor job, schedule, and host registries
- runtime host and deployment target registries
- brand system registry (voice, identity, motion)
- creative systems registry (direction, campaign briefs, copy deck)
- content model registry (launch, case study, 3D scene)
- editorial workflow registry
- email template registry (welcome, launch, activation)
- icon system, motion library, and illustration library registries
- social presence and channel registry
- content calendar registry
- release pipeline registry
- QA program registry
- domain + edge stack registry
- trust center registry
- compliance framework registry (SOC2, ISO, HIPAA, PCI, GDPR)
- edge runtime registry (edge execution + cache routing)
- worker runtime registry (cron + queue workers)
- API gateway registry (routing + validation)
- rate limit registry (route + actor throttling)
- cache stack registry (edge/session/search cache lanes)
- search stack registry (text + vector + hybrid)
- storage stack registry (artifacts, uploads, archives)
- session store registry (cookie + token + actor sessions)
- marketplace stack registry
- content syndication registry (rss, email, partner embeds)
